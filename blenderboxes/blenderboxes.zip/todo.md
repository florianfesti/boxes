
# Assign a custom property to an existing type.
bpy.types.Material.custom_float = bpy.props.FloatProperty(name="Test Property")

Properties can also be updated through update callbacks, app handlers, getters/setters, manually through through snippet execution, and potentially elsewhere though I can’t recall doing so.
Reliance on operators to update props would make many complex addons impossible.

Le temps de chargement ? 
La description qqpart ?
replace le meme svg
join all parts
generator sans images ?
